package denmarkProject;

public class SingleHolidayScreen {

	int holidayId; 
	public SingleHolidayScreen(int holidayId) {
		this.holidayId = holidayId;
	}
	
}
