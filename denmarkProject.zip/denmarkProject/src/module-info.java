/**
 * 
 */
/**
 * @author strothcc
 *
 */
module denmarkProject {
	requires java.desktop;
}